The zip archive contains the following:
-this README.txt
-an executable jar file that runs the program on windows
-a directory named res with all the resources necessary for the application to start



The name of the player is changed by changing the first line in the changeableInfo.txt file
which is located in the directory res.
The IP that the game will connect to is on the second line in the same textfile.